<?php
session_start();
$login = $_SESSION['user'];
$rank = $_GET['rank'];
$price = $_GET['price'];

$merchant_id = "YOUR_ID";
$secret = "YOUR_SECRET";

$order_id = rand(1000,9999);
$sign = md5($merchant_id.":".$price.":".$secret.":".$order_id);

$url = "https://pay.freekassa.ru/?m=".$merchant_id."&oa=".$price."&o=".$order_id."&s=".$sign."&us_login=".$login."&us_rank=".$rank;
header("Location: $url");
?>