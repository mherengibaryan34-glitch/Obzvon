<?php
include "config.php";

$secret = "YOUR_SECRET";

$sign = md5($_POST['MERCHANT_ID'].":".$_POST['AMOUNT'].":".$secret.":".$_POST['MERCHANT_ORDER_ID']);
if ($sign != $_POST['SIGN']) die("error");

$login = $_POST['us_login'];
$amount = $_POST['AMOUNT'];
$rank = $_POST['us_rank'];

mysqli_query($conn, "UPDATE users SET balance=balance+$amount WHERE login='$login'");
file_put_contents("logs.txt", "$login купил $rank\n", FILE_APPEND);

echo "YES";
?>