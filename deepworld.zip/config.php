<?php
$conn = mysqli_connect("localhost","root","","deepworld");
if (!$conn) {
    die("Ошибка БД");
}
?>