<?php session_start(); ?>
<link rel="stylesheet" href="style.css">
<h1>DeepWorld</h1>
<div class="cards">
<div class="card">
<h3>VIP</h3>
<p>100₽</p>
<a href="buy.php?rank=VIP&price=100">Купить</a>
</div>
<div class="card">
<h3>PREMIUM</h3>
<p>300₽</p>
<a href="buy.php?rank=PREMIUM&price=300">Купить</a>
</div>
</div>