<?php
session_start();
include "config.php";

if ($_POST) {
    $login = $_POST['login'];
    $pass = md5($_POST['pass']);

    $res = mysqli_query($conn, "SELECT * FROM users WHERE login='$login' AND password='$pass'");

    if (mysqli_num_rows($res)) {
        $_SESSION['user'] = $login;
        header("Location: profile.php");
    } else {
        echo "Ошибка";
    }
}
?>
<form method="POST">
<input name="login">
<input name="pass" type="password">
<button>Войти</button>
</form>