<?php
session_start();
include "config.php";

$login = $_SESSION['user'];

$res = mysqli_query($conn, "SELECT * FROM users WHERE login='$login'");
$user = mysqli_fetch_assoc($res);
?>
<h1>DeepWorld</h1>
<p>Ник: <?php echo $login; ?></p>
<p>Баланс: <?php echo $user['balance']; ?>₽</p>
<a href="index.php">Магазин</a>