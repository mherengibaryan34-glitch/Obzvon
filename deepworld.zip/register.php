<?php
include "config.php";

if ($_POST) {
    $login = $_POST['login'];
    $pass = md5($_POST['pass']);

    mysqli_query($conn, "INSERT INTO users(login,password,balance) VALUES('$login','$pass',0)");
    echo "Аккаунт создан";
}
?>
<form method="POST">
<input name="login" placeholder="Логин">
<input name="pass" type="password" placeholder="Пароль">
<button>Регистрация</button>
</form>